﻿public enum TimeFrame
{
    Year,
    TwoYears,
    Long
}